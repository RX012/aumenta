// Server-only helper for the Primecash Brasil API
// Docs: https://primecashbrasil.readme.io/reference/introducao
// Auth: HTTP Basic with `${SECRET_KEY}:x`

const BASE_URL = "https://api.primecashbrasil.com/v1";

function authHeader(): string {
  const secret = process.env.PRIMECASH_SECRET_KEY;
  if (!secret) throw new Error("PRIMECASH_SECRET_KEY not configured");
  return `Basic ${btoa(`${secret}:x`)}`;
}

export type PixCustomer = {
  name: string;
  email: string;
  cpf: string; // only digits (11)
  phone?: string; // optional, format "11999999999"
};

export type CreatePixInput = {
  amountCents: number; // value in cents (R$ 5,00 = 500)
  itemTitle: string;
  customer: PixCustomer;
  externalRef?: string;
  metadata?: string;
  postbackUrl?: string;
};

export type CreatePixResponse = {
  id: number | string;
  status: string;
  amount: number;
  secureId?: string;
  secureUrl?: string;
  pix?: {
    qrcode: string;
    url?: string;
    expirationDate?: string;
    createdAt?: string;
  };
  [k: string]: unknown;
};

export async function createPixTransaction(
  input: CreatePixInput,
): Promise<CreatePixResponse> {
  const body = {
    amount: input.amountCents,
    paymentMethod: "pix",
    customer: {
      name: input.customer.name,
      email: input.customer.email,
      document: { number: input.customer.cpf, type: "cpf" },
      ...(input.customer.phone ? { phone: input.customer.phone } : {}),
    },
    items: [
      {
        title: input.itemTitle,
        unitPrice: input.amountCents,
        quantity: 1,
        tangible: false,
      },
    ],
    pix: { expiresInDays: 1 },
    ...(input.metadata ? { metadata: input.metadata } : {}),
    ...(input.externalRef ? { externalRef: input.externalRef } : {}),
    ...(input.postbackUrl ? { postbackUrl: input.postbackUrl } : {}),
  };

  const res = await fetch(`${BASE_URL}/transactions`, {
    method: "POST",
    headers: {
      Authorization: authHeader(),
      "Content-Type": "application/json",
      Accept: "application/json",
      "User-Agent": "AumentaDigital/1.0 (+https://aumenta-digital-br.lovable.app)",
    },
    body: JSON.stringify(body),
  });

  const text = await res.text();
  let json: any;
  try { json = JSON.parse(text); } catch { json = { raw: text }; }

  if (!res.ok) {
    const msg = json?.message || json?.error || text || `HTTP ${res.status}`;
    throw new Error(`Primecash error (${res.status}): ${msg}`);
  }
  return json as CreatePixResponse;
}

export async function getTransaction(id: string | number): Promise<CreatePixResponse> {
  const res = await fetch(`${BASE_URL}/transactions/${encodeURIComponent(String(id))}`, {
    method: "GET",
    headers: {
      Authorization: authHeader(),
      Accept: "application/json",
    },
  });
  const text = await res.text();
  let json: any;
  try { json = JSON.parse(text); } catch { json = { raw: text }; }
  if (!res.ok) {
    const msg = json?.message || json?.error || text || `HTTP ${res.status}`;
    throw new Error(`Primecash error (${res.status}): ${msg}`);
  }
  return json as CreatePixResponse;
}
