// UTMify Orders API helper (server-only)
// Docs: https://docs.utmify.com.br/orders
const ORDERS_URL = "https://api.utmify.com.br/api-credentials/orders";

export type UtmifyStatus = "waiting_payment" | "paid" | "refused" | "refunded" | "chargedback";

export type UtmifyTracking = {
  src?: string | null;
  sck?: string | null;
  utm_source?: string | null;
  utm_medium?: string | null;
  utm_campaign?: string | null;
  utm_content?: string | null;
  utm_term?: string | null;
};

export type UtmifyCustomer = {
  name: string;
  email: string;
  phone?: string | null;
  document?: string | null;
  country?: string;
  ip?: string | null;
};

export type UtmifyProduct = {
  id: string;
  name: string;
  planId?: string | null;
  planName?: string | null;
  quantity: number;
  priceInCents: number;
};

export type UtmifyOrderPayload = {
  orderId: string;
  platform: string; // e.g. "Primecash"
  paymentMethod: "pix" | "credit_card" | "boleto";
  status: UtmifyStatus;
  createdAt: string; // "YYYY-MM-DD HH:mm:ss" UTC
  approvedDate: string | null;
  refundedAt?: string | null;
  customer: UtmifyCustomer;
  products: UtmifyProduct[];
  trackingParameters: UtmifyTracking;
  commission: {
    totalPriceInCents: number;
    gatewayFeeInCents: number;
    userCommissionInCents: number;
  };
  isTest?: boolean;
};

export function utmifyDate(d: Date = new Date()): string {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`;
}

export async function sendUtmifyOrder(payload: UtmifyOrderPayload): Promise<void> {
  const token = process.env.UTMIFY_API_TOKEN;
  if (!token) {
    console.warn("[utmify] UTMIFY_API_TOKEN not configured; skipping");
    return;
  }
  try {
    const res = await fetch(ORDERS_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-token": token,
      },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const txt = await res.text().catch(() => "");
      console.error("[utmify] HTTP", res.status, txt.slice(0, 500));
    }
  } catch (err) {
    console.error("[utmify] error", err);
  }
}
