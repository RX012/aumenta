import { createFileRoute } from "@tanstack/react-router";
import { createPixTransaction } from "@/lib/primecash.server";
import { sendUtmifyOrder, utmifyDate, type UtmifyTracking } from "@/lib/utmify.server";

// Server-side price table — single source of truth.
// Prices in cents (R$). Index 1..N per service.
const PRICES_CENTS = {
  seguidores: [1490, 1990, 2490, 2990, 3990, 4990, 6990, 7990, 9990],
  curtidas:   [1490, 1990, 2490, 2990, 3990, 4990, 5990, 6990, 7990],
  visualizacoes: [990, 1490, 2490, 3990, 5790, 9490, 15990, 23990, 39990],
  comentarios: [990, 1690, 3290, 4990, 7990, 12990],
} as const;

const QTY_LABEL: Record<string, string[]> = {
  seguidores: ["1.000","3.000","5.000","10.000","15.000","20.000","40.000","50.000","100.000"],
  curtidas:   ["200","500","800","1.500","1.700","2.000","3.000","4.500","5.000"],
  visualizacoes: ["3.000","5.000","10.000","20.000","50.000","100.000","200.000","500.000","1.000.000"],
  comentarios: ["5","10","20","30","50","100"],
};

const SERVICE_LABEL: Record<string, string> = {
  seguidores: "Seguidores BR",
  curtidas: "Curtidas BR",
  visualizacoes: "Visualizações em Reels",
  comentarios: "Comentários BR",
};

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...CORS },
  });
}

function cleanDigits(v: string) { return (v || "").replace(/\D/g, ""); }

function isValidCpf(cpf: string) {
  cpf = cleanDigits(cpf);
  if (cpf.length !== 11 || /^(\d)\1{10}$/.test(cpf)) return false;
  const calc = (slice: number) => {
    let sum = 0;
    for (let i = 0; i < slice; i++) sum += parseInt(cpf[i], 10) * (slice + 1 - i);
    const r = (sum * 10) % 11;
    return r === 10 ? 0 : r;
  };
  return calc(9) === parseInt(cpf[9], 10) && calc(10) === parseInt(cpf[10], 10);
}

export const Route = createFileRoute("/api/public/pix/create")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS }),
      POST: async ({ request }) => {
        try {
          const body = await request.json().catch(() => ({})) as Record<string, unknown>;
          const service = String(body.service ?? "").toLowerCase();
          const pkg = parseInt(String(body.pkg ?? "0"), 10);
          const profile = String(body.profile ?? "").trim().slice(0, 120);
          const platform = (String(body.platform ?? "instagram").toLowerCase() === "tiktok") ? "tiktok" : "instagram";
          const name = String(body.name ?? "").trim().slice(0, 100);
          const email = String(body.email ?? "").trim().toLowerCase().slice(0, 120);
          const cpf = cleanDigits(String(body.cpf ?? ""));
          const phone = cleanDigits(String(body.phone ?? "")).slice(0, 11);

          if (!(service in PRICES_CENTS)) return json({ error: "Serviço inválido" }, 400);
          const prices = PRICES_CENTS[service as keyof typeof PRICES_CENTS];
          if (!Number.isFinite(pkg) || pkg < 1 || pkg > prices.length) {
            return json({ error: "Pacote inválido" }, 400);
          }
          if (!profile) return json({ error: "Informe o @ do Instagram ou link" }, 400);
          if (name.length < 2) return json({ error: "Informe o nome completo" }, 400);
          if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({ error: "Email inválido" }, 400);
          if (!isValidCpf(cpf)) return json({ error: "CPF inválido" }, 400);

          // Order bumps — cross-sell: cada bump é { service, pkg } validado no catálogo.
          const rawBumps = Array.isArray((body as any).bumps) ? (body as any).bumps : [];
          const bumps: { label: string; cents: number; service: string; pkg: number }[] = [];
          for (const b of rawBumps.slice(0, 4)) {
            const bSvc = String(b?.service ?? "").toLowerCase();
            const bPkg = parseInt(String(b?.pkg ?? "0"), 10);
            if (!(bSvc in PRICES_CENTS)) continue;
            const bPrices = PRICES_CENTS[bSvc as keyof typeof PRICES_CENTS];
            if (!Number.isFinite(bPkg) || bPkg < 1 || bPkg > bPrices.length) continue;
            bumps.push({
              service: bSvc,
              pkg: bPkg,
              cents: bPrices[bPkg - 1],
              label: `${QTY_LABEL[bSvc][bPkg - 1]} ${SERVICE_LABEL[bSvc]}`,
            });
          }
          const bumpCents = bumps.reduce((s, b) => s + b.cents, 0);
          const amount = prices[pkg - 1] + bumpCents;
          const qty = QTY_LABEL[service][pkg - 1];
          const platformLabel = platform === "tiktok" ? "TikTok" : "Instagram";
          const bumpSuffix = bumps.length ? ` + ${bumps.map(b => b.label).join(" + ")}` : "";
          const title = `${qty} ${SERVICE_LABEL[service]} — ${platformLabel} (${profile})${bumpSuffix}`;

          // Tracking params (utm_*/sck/src) — sent by checkout from URL/localStorage
          const rawTracking = (body as any).tracking || {};
          const tracking: UtmifyTracking = {
            src: rawTracking.src ? String(rawTracking.src).slice(0, 120) : null,
            sck: rawTracking.sck ? String(rawTracking.sck).slice(0, 120) : null,
            utm_source: rawTracking.utm_source ? String(rawTracking.utm_source).slice(0, 120) : null,
            utm_medium: rawTracking.utm_medium ? String(rawTracking.utm_medium).slice(0, 120) : null,
            utm_campaign: rawTracking.utm_campaign ? String(rawTracking.utm_campaign).slice(0, 120) : null,
            utm_content: rawTracking.utm_content ? String(rawTracking.utm_content).slice(0, 120) : null,
            utm_term: rawTracking.utm_term ? String(rawTracking.utm_term).slice(0, 120) : null,
          };

          // Build postback URL. Always point to the published domain so Primecash
          // accepts it (preview/sandbox URLs are rejected by the gateway WAF).
          const postbackUrl = "https://aumenta-digital-br.lovable.app/api/public/primecash/webhook";

          // Stash tracking + product info in metadata so the webhook can replay it to UTMify
          const metaPayload = { service, pkg, profile, platform, bumps, tracking, amount };
          const metadata = JSON.stringify(metaPayload).slice(0, 2000);

          const tx = await createPixTransaction({
            amountCents: amount,
            itemTitle: title.slice(0, 120),
            customer: { name, email, cpf, phone: phone || undefined },
            externalRef: `${platform}:${service}:${pkg}:${profile}`.slice(0, 120),
            metadata,
            postbackUrl,
          });

          // Defensive: Primecash returns pix code on different paths depending on account/version.
          const anyTx = tx as any;
          const pix = anyTx.pix || anyTx.pixData || anyTx.data?.pix || {};
          const qrcode =
            pix.qrcode || pix.qrCode || pix.payload || pix.emv ||
            pix.qrcodeText || pix.copy_paste || pix.copyPaste || null;
          if (!qrcode) {
            console.error("[pix/create] no qrcode in response", JSON.stringify(anyTx).slice(0, 1000));
            return json({ error: "Resposta do gateway sem código PIX. Tente novamente em instantes." }, 502);
          }

          // Send "waiting_payment" to UTMify — fire-and-forget, errors only logged
          const orderId = String(tx.id);
          const products = [
            {
              id: `${service}-${pkg}`,
              name: `${qty} ${SERVICE_LABEL[service]} (${platformLabel})`,
              planId: null,
              planName: null,
              quantity: 1,
              priceInCents: prices[pkg - 1],
            },
            ...bumps.map((b) => ({
              id: `${b.service}-${b.pkg}`,
              name: b.label,
              planId: null,
              planName: null,
              quantity: 1,
              priceInCents: b.cents,
            })),
          ];
          const ip =
            request.headers.get("cf-connecting-ip") ||
            request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
            "0.0.0.0";
          await sendUtmifyOrder({
            orderId,
            platform: "Primecash",
            paymentMethod: "pix",
            status: "waiting_payment",
            createdAt: utmifyDate(),
            approvedDate: null,
            refundedAt: null,
            customer: { name, email, phone: phone || null, document: cpf, country: "BR", ip },
            products,
            trackingParameters: tracking,
            commission: { totalPriceInCents: amount, gatewayFeeInCents: 0, userCommissionInCents: amount },
            isTest: false,
          });

          return json({
            ok: true,
            id: tx.id,
            status: tx.status,
            amount: tx.amount,
            qrcode,
            expirationDate: pix.expirationDate || pix.expires_at || null,
            secureUrl: anyTx.secureUrl || anyTx.secure_url || null,
          });
        } catch (err) {
          console.error("[pix/create]", err);
          const msg = err instanceof Error ? err.message : "Erro ao gerar PIX";
          return json({ error: msg }, 500);
        }
      },
    },
  },
});
