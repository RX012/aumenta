import { createFileRoute } from "@tanstack/react-router";
import { getTransaction } from "@/lib/primecash.server";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...CORS },
  });
}

export const Route = createFileRoute("/api/public/pix/status/$id")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS }),
      GET: async ({ params }) => {
        try {
          const id = String(params.id || "").replace(/[^a-zA-Z0-9-]/g, "").slice(0, 64);
          if (!id) return json({ error: "ID inválido" }, 400);
          const tx = await getTransaction(id);
          return json({
            ok: true,
            id: tx.id,
            status: tx.status, // paid | waiting_payment | refused | refunded | ...
            amount: tx.amount,
            paidAt: (tx as any).paidAt || null,
          });
        } catch (err) {
          console.error("[pix/status]", err);
          const msg = err instanceof Error ? err.message : "Erro";
          return json({ error: msg }, 500);
        }
      },
    },
  },
});
