import { createFileRoute } from "@tanstack/react-router";
import { getTransaction } from "@/lib/primecash.server";
import { sendUtmifyOrder, utmifyDate, type UtmifyStatus } from "@/lib/utmify.server";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

const SERVICE_LABEL: Record<string, string> = {
  seguidores: "Seguidores BR",
  curtidas: "Curtidas BR",
  visualizacoes: "Visualizações em Reels",
  comentarios: "Comentários BR",
};

const QTY_LABEL: Record<string, string[]> = {
  seguidores: ["1.000","3.000","5.000","10.000","15.000","20.000","40.000","50.000","100.000"],
  curtidas:   ["200","500","800","1.500","1.700","2.000","3.000","4.500","5.000"],
  visualizacoes: ["3.000","5.000","10.000","20.000","50.000","100.000","200.000","500.000","1.000.000"],
  comentarios: ["5","10","20","30","50","100"],
};

function mapStatus(s: string | undefined): UtmifyStatus | null {
  switch ((s || "").toLowerCase()) {
    case "paid":
    case "approved":
      return "paid";
    case "waiting_payment":
    case "pending":
      return "waiting_payment";
    case "refused":
    case "failed":
      return "refused";
    case "refunded":
      return "refunded";
    case "chargedback":
      return "chargedback";
    default:
      return null;
  }
}

export const Route = createFileRoute("/api/public/primecash/webhook")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS }),
      POST: async ({ request }) => {
        try {
          const raw = await request.text();
          let body: any = {};
          try { body = JSON.parse(raw); } catch {}

          // Primecash payloads vary; try common shapes
          const txId =
            body?.id ?? body?.transactionId ?? body?.transaction?.id ??
            body?.data?.id ?? body?.data?.transaction?.id ?? null;
          if (!txId) {
            console.error("[primecash/webhook] no id in payload", raw.slice(0, 500));
            return new Response("ok", { status: 200, headers: CORS });
          }

          // Authoritative: re-fetch transaction from Primecash
          const tx: any = await getTransaction(txId);
          const status = mapStatus(tx.status);
          if (!status) {
            console.warn("[primecash/webhook] unmapped status", tx.status);
            return new Response("ok", { status: 200, headers: CORS });
          }

          // Restore tracking + product info from metadata
          let meta: any = {};
          try { meta = tx.metadata ? JSON.parse(tx.metadata) : {}; } catch {}
          const tracking = meta.tracking || {};
          const service = String(meta.service || "");
          const pkg = Number(meta.pkg || 0);
          const platform = meta.platform === "tiktok" ? "TikTok" : "Instagram";
          const bumps = Array.isArray(meta.bumps) ? meta.bumps : [];

          const products = [];
          if (service && QTY_LABEL[service]?.[pkg - 1]) {
            products.push({
              id: `${service}-${pkg}`,
              name: `${QTY_LABEL[service][pkg - 1]} ${SERVICE_LABEL[service]} (${platform})`,
              planId: null,
              planName: null,
              quantity: 1,
              priceInCents: Number(meta.amount || tx.amount) - bumps.reduce((s: number, b: any) => s + (b.cents || 0), 0),
            });
          }
          for (const b of bumps) {
            products.push({
              id: `${b.service}-${b.pkg}`,
              name: b.label,
              planId: null,
              planName: null,
              quantity: 1,
              priceInCents: b.cents,
            });
          }

          const customer = tx.customer || {};
          const amount = Number(tx.amount || meta.amount || 0);

          await sendUtmifyOrder({
            orderId: String(tx.id),
            platform: "Primecash",
            paymentMethod: "pix",
            status,
            createdAt: utmifyDate(new Date(tx.createdAt || Date.now())),
            approvedDate: status === "paid" ? utmifyDate(new Date(tx.paidAt || Date.now())) : null,
            refundedAt: status === "refunded" ? utmifyDate(new Date(tx.refundedAt || Date.now())) : null,
            customer: {
              name: customer.name || "",
              email: customer.email || "",
              phone: customer.phone || null,
              document: customer.document?.number || customer.document || null,
              country: "BR",
              ip: null,
            },
            products,
            trackingParameters: tracking,
            commission: { totalPriceInCents: amount, gatewayFeeInCents: 0, userCommissionInCents: amount },
            isTest: false,
          });

          return new Response("ok", { status: 200, headers: CORS });
        } catch (err) {
          console.error("[primecash/webhook]", err);
          // Return 200 so Primecash doesn't endlessly retry; errors are logged
          return new Response("ok", { status: 200, headers: CORS });
        }
      },
    },
  },
});
