import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Aumenta Digital — Seguidores, Curtidas, Comentários e Views" },
      { name: "description", content: "Compre seguidores, curtidas, comentários e visualizações para Instagram. Entrega rápida e pagamento 100% seguro." },
    ],
  }),
  component: Index,
});

function Index() {
  useEffect(() => {
    window.location.replace("/instagram.html");
  }, []);
  return (
    <div className="flex min-h-screen items-center justify-center bg-white text-slate-600">
      Redirecionando para Aumenta Digital…
    </div>
  );
}
