# Deploy na Vercel — Aumenta Digital

Projeto **TanStack Start** otimizado para Vercel (preset nitro `vercel`, edge cache nos assets, sem SSR pesado nas páginas de checkout — são HTML estático em `/public`).

## Passo a passo

1. **Descompacte o zip** e suba a pasta para um repositório (GitHub/GitLab/Bitbucket) — ou use `vercel` CLI direto.

2. **Importe na Vercel**: New Project → Import do repo.
   - Framework Preset: **Other** (o `vercel.json` já configura tudo)
   - Build Command: `bun run build` (já no vercel.json)
   - Output: detectado automaticamente pelo preset nitro `vercel`

3. **Variáveis de ambiente** (Settings → Environment Variables) — copie do `.env.example`:
   - `PRIMECASH_SECRET_KEY` = `sk_live_v2mmPEMwi8KSLFsQygQrR5DwAl5l5uLlmhBsv1u3gg`
   - `UTMIFY_API_TOKEN` = `uxPqZMvdEgxI9J4HBmdfo8HERQLJrAsTJFq2`
   - `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY`, `VITE_SUPABASE_PROJECT_ID`
   - `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`, `SUPABASE_PROJECT_ID`

4. **Deploy** → Vercel constrói e publica.

5. **Atualize o postback URL** em `src/routes/api/public/pix/create.ts` (linha ~117) para o seu domínio Vercel:
   ```ts
   const postbackUrl = "https://SEU-DOMINIO.vercel.app/api/public/primecash/webhook";
   ```
   Depois faça redeploy.

6. **No painel UTMify e Primecash**, configure o webhook para o mesmo URL acima.

## Performance

- HTMLs estáticos (`/instagram.html`, `/checkout.html`) servidos pela CDN da Vercel — TTFB < 50 ms global.
- Assets com `Cache-Control: immutable` (1 ano).
- API PIX roda em **Edge Functions** (preset nitro vercel) — latência baixa.

## Rodando localmente

```bash
bun install
cp .env.example .env
bun run dev
```
